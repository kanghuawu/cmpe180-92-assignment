#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>

using namespace std;

// Names to search for.
const string MAKAR  = "Makar Alexeevich";
const string JOSEPH = "Joseph Bazdeev";
const string BORIS  = "Boris Drubetskoy";

// vector to store the file line by line
vector<string> WarNPeace;

const string INPUT_FILE_NAME = "WarAndPeace.txt";


void findName(int lineNo, string name);    //find the given name in a given line number
void splitName(string name, string& firstName, string& lastName);    //split the name and store into firstName and lastName


int main()
{
    ifstream input;
    input.open(INPUT_FILE_NAME);
    if (input.fail())
    {
        cout << "Failed to open " << INPUT_FILE_NAME << endl;
        return -1;
    }

    //retrieve lines from file and store into a vector
    string toStore;
    while (getline(input, toStore)) {
        WarNPeace.push_back(toStore);
    }
    
    //print the header
    cout << setw(5) << "LINE" << setw(10) << "POSITION" << " " << "NAME" <<endl;
    
    //finding names line by line
    for (int i=0; i<WarNPeace.size(); i++) {
        findName(i, MAKAR);
        findName(i, JOSEPH);
        findName(i, BORIS);
    }
    
    
    return 0;
}

void findName(int lineNo, string name){
    string firstName;
    string lastName;
    splitName(name, firstName, lastName);
    
    string firstLine = WarNPeace.at(lineNo);
    size_t fullNamePos = firstLine.find(name);
    size_t firstNamePos = firstLine.find(firstName);
    
    //find the full name in a line
    if (fullNamePos <= firstLine.size()) {
        cout << setw(5) << lineNo + 1 << setw(10) << fullNamePos+1 << " " << name <<endl;
    }
    
    //find the name split into two lines
    if (lineNo+1 <= WarNPeace.size() && firstNamePos + firstName.size() == firstLine.size()){
        string secondLine = WarNPeace.at(lineNo+1);
        size_t lastNamePos = secondLine.find(lastName);
        if(lastNamePos==0){
            cout << setw(5) << lineNo + 1 << setw(10) << firstNamePos+1 << " " << name <<endl;
        }
    }
}

void splitName(string name, string &firstName, string &lastName){
    firstName = "";
    lastName = "";
    bool split = false;
    for (auto it=name.begin(); it<name.end(); it++) {
        if (isspace(*it)) {
            split = true;
        }else if(isalpha(*it)){
            if (split == false) {
                firstName.push_back(*it);
            }else if (split == true){
                lastName.push_back(*it);
            }
        }
    }
}
