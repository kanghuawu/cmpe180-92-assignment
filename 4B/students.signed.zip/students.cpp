#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

const string INPUT_FILE_NAME = "students.txt";
void createTable(ifstream &input, string &subject, string* &names, int** &scores, int &studentNum);
void getPersonScore(string line, int* &personScore);
void printTable(string subject, string* names, int** scores, int studentNum);

/**
 * Main.
 */
int main()
{
    ifstream input;
    input.open(INPUT_FILE_NAME);
    if (input.fail())
    {
        cout << "Failed to open " << INPUT_FILE_NAME << endl;
        return -1;
    }
    
    string subject;
    string* names;
    int** scores;
    int studentNum;
    createTable(input, subject, names, scores, studentNum);
    
    printTable(subject, names, scores, studentNum);
    delete [] names;
    delete [] scores;
}

void createTable(ifstream &input, string &subject,string* &names, int** &scores, int &studentNum){
    string line;
    getline(input, line);
    size_t spaceIndex = line.find(' ');
    subject = line.substr(0, spaceIndex);
    studentNum = stoi(line.substr(spaceIndex+1));
//    cout << studentNum << endl;
    names = new string[studentNum];
    scores = new int*[studentNum];
    for (int i=0; i<studentNum; i++) {
        getline(input, line);
        spaceIndex = line.find(' ');
        spaceIndex = line.find(' ', spaceIndex +1);
        
        names[i] = line.substr(0,spaceIndex);
        int* personScore;
        line = line.substr(spaceIndex+1);
        getPersonScore(line, personScore);
        scores[i] = personScore;
    }
}

void getPersonScore(string line, int* &personScore)
{
//    cout << line << endl;
    size_t spaceIndex = line.find(' ');
    int personNumScore = stoi(line.substr(0,spaceIndex));
    personScore = new int[personNumScore+1];
    line = line.substr(spaceIndex+1);
//    cout << "<<" << line << ">>" << endl;
    spaceIndex = line.find(' ');
    for (int i=0; i<=personNumScore; i++) {
        if (i == personNumScore) {
            personScore[i] = 101;
        }else{
            if (line.find(' ', spaceIndex)<line.size()) {
                personScore[i] = stoi(line.substr(0, spaceIndex));
                line = line.substr(spaceIndex+1);
                spaceIndex = line.find(' ');
//                cout << spaceIndex << endl;
            }else{
                personScore[i] = stoi(line);
//                cout << line ;
            }
        }
//        cout << personScore[i] << " ";
    }
//        cout << endl;
}

void printTable(string subject, string* names, int** scores, int studentNum){
    cout << "STUDENT SCORES for " << subject << endl << endl;
    for (int i=0; i<studentNum; i++) {
        int* personScore = scores[i];
        int j=0;
        cout << names[i] << endl;
        if (personScore[0] == 101) {
            cout << setw(10) << "(none)";
        }else{
            while (personScore[j]!=101) {
                cout << setw(5) << personScore[j];
                j++;
            }
        }
        cout << endl << endl;
    }
}